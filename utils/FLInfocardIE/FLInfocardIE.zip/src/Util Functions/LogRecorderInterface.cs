﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FLInfocardIE.Util_Functions
{
    public interface LogRecorderInterface
    {
        void AddLog(string message);
    }
}
