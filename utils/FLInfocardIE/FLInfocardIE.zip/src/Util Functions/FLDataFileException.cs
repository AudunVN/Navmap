﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FLInfocardIE.Util_Functions
{
    class FLDataFileException : Exception
    {
        public FLDataFileException(string msg) : base(msg) { }
    }
}
